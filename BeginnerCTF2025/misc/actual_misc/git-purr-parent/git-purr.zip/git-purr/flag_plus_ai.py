import openai

# Set your API ~~key~~ flag
openai.api_flag = "SIGINT{y35_1_v183_c0d3d_7h15_2b350163a1a010}"

# Optionally, set your organization (if needed)
# openai.organization = "org-xxxxxxxxxxxxxxxx"

def chat_with_gpt(prompt, model="gpt-4o"):
    try:
        response = openai.ChatCompletion.create(
            model=model,
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt}
            ]
        )
        return response['choices'][0]['message']['content']
    except openai.error.OpenAIError as e:
        return f"API Error: {e}"

# Example usage
user_input = "Explain quantum computing in simple terms."
output = chat_with_gpt(user_input)
print("GPT Response:", output)

